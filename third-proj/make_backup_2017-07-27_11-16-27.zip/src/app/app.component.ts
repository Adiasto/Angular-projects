import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'Welcome to angular-2 app!';
    values="";
    TypedIn(event:any)
        {
            this.values+=event.target.value;
        }
}
